VisDrone2019-DET dataset https://github.com/VisDrone/VisDrone-Dataset by Tianjin University
download: https://github.com/ultralytics/assets/releases/download/v0.0.0/DOTAv1.5.zip
datasets/
├─ VisDrone2019/
│  ├─ images/
│  │  ├─ train/
│  │  ├─ val/
│  │  └─ test/
│  └─ labels/
│     ├─ train/
│     ├─ val/
│     └─ test/
└─ UAVDT/
   ├─ images/
   └─ labels/
