import torch
from ultralytics import YOLO
import cv2
import os
from pathlib import Path
import time
import numpy as np


def batch_yolov11_detect(model_path, image_dir, output_dir="results_visdrone/ours", conf=0.25, iou=0.45, warmup_epochs=10,
                         test_epochs=100):
    """
    批量YOLOv11推理函数 - 支持整个文件夹的图片处理，包含FPS计算
    """
    # 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    # 加载模型
    model = YOLO(model_path)

    # 设置模型为评估模式
    model.model.eval()

    print(f"模型加载成功: {model_path}")
    print(f"输入图片目录: {image_dir}")
    print(f"输出目录: {output_dir}")

    # 获取所有图片文件
    image_extensions = ['*.jpg', '*.jpeg', '*.png', '*.bmp', '*.tiff']
    image_paths = []
    for ext in image_extensions:
        image_paths.extend(Path(image_dir).glob(ext))
        image_paths.extend(Path(image_dir).glob(ext.upper()))

    if not image_paths:
        print("未找到图片文件！")
        return None

    print(f"找到 {len(image_paths)} 张图片")

    # FPS测试 - 使用第一张图片进行基准测试
    if image_paths:
        print("\n开始FPS性能测试...")
        fps, avg_inference_time = calculate_fps(model, str(image_paths[0]), warmup_epochs, test_epochs)
        print(f"模型推理FPS: {fps:.2f}")
        print(f"平均推理时间: {avg_inference_time:.2f} ms")

    # 使用YOLO原生批量处理功能
    print("\n开始批量处理图片...")
    start_time = time.time()

    results = model.predict(
        source=image_dir,
        conf=conf,
        iou=iou,
        save=True,
        project=output_dir,
        name="predictions",
        exist_ok=True
    )

    # 计算总处理时间（包括IO和保存时间）
    total_processing_time = time.time() - start_time
    total_fps = len(image_paths) / total_processing_time if total_processing_time > 0 else 0

    # 统计结果
    total_detections = 0
    for i, result in enumerate(results):
        if result.boxes is not None:
            detections = len(result.boxes)
            total_detections += detections
            print(f"图片 {i + 1}: 检测到 {detections} 个目标")
        else:
            print(f"图片 {i + 1}: 未检测到目标")

    print(f"\n批量处理完成！")
    print(f"总共处理 {len(image_paths)} 张图片")
    print(f"检测到 {total_detections} 个目标")
    print(f"总处理时间: {total_processing_time:.2f} 秒")
    print(f"整体FPS (包含IO): {total_fps:.2f}")
    print(f"结果保存在: {output_dir}/predictions/")

    return results, total_fps


def calculate_fps(model, image_path, warmup_epochs=10, test_epochs=100):
    """
    计算模型的FPS性能
    """
    # 读取测试图片
    image = cv2.imread(image_path)
    if image is None:
        print(f"无法读取图片: {image_path}")
        return 0, 0

    # 预热阶段（让GPU达到稳定状态）
    print("预热阶段...")
    with torch.no_grad():
        for _ in range(warmup_epochs):
            _ = model(image)

    # 正式测试
    print("正式FPS测试...")
    inference_times = []

    with torch.no_grad():
        for _ in range(test_epochs):
            start_time = time.time()
            results = model(image)
            end_time = time.time()

            inference_time = (end_time - start_time) * 1000  # 转换为毫秒
            inference_times.append(inference_time)

    # 计算统计数据
    avg_inference_time = np.mean(inference_times)
    std_inference_time = np.std(inference_times)
    fps = 1000 / avg_inference_time  # 转换为FPS

    print(f"FPS测试结果:")
    print(f"- 平均推理时间: {avg_inference_time:.2f} ± {std_inference_time:.2f} ms")
    print(f"- 最大推理时间: {max(inference_times):.2f} ms")
    print(f"- 最小推理时间: {min(inference_times):.2f} ms")
    print(f"- 推理FPS: {fps:.2f}")

    return fps, avg_inference_time


def real_time_fps_test(model_path, camera_index=0, duration=10):
    """
    实时摄像头FPS测试（可选功能）
    """
    model = YOLO(model_path)
    cap = cv2.VideoCapture(camera_index)

    if not cap.isOpened():
        print("无法打开摄像头")
        return

    print("开始实时FPS测试（按'q'退出）...")

    frame_count = 0
    start_time = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # 推理
        results = model(frame)

        # 显示结果
        annotated_frame = results[0].plot()
        cv2.imshow('YOLOv11 Real-time Detection', annotated_frame)

        frame_count += 1
        elapsed_time = time.time() - start_time
        current_fps = frame_count / elapsed_time

        # 显示实时FPS
        cv2.putText(annotated_frame, f'FPS: {current_fps:.2f}', (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

        cv2.imshow('YOLOv11 Real-time Detection', annotated_frame)

        # 按q退出或达到测试时长
        if cv2.waitKey(1) & 0xFF == ord('q') or elapsed_time >= duration:
            break

    # 计算最终FPS
    total_time = time.time() - start_time
    final_fps = frame_count / total_time if total_time > 0 else 0

    print(f"实时测试结果:")
    print(f"- 总帧数: {frame_count}")
    print(f"- 总时间: {total_time:.2f} 秒")
    print(f"- 平均FPS: {final_fps:.2f}")

    cap.release()
    cv2.destroyAllWindows()

    return final_fps


# 使用示例
if __name__ == "__main__":
    # 批量图片处理 + FPS测试
    results, fps = batch_yolov11_detect(

        model_path=r'weights/AFPM-Net.pt',
        image_dir=r"docs"
    )

    # # 可选：实时摄像头测试（取消注释以启用）
    # print("\n开始实时摄像头测试...")
    # real_time_fps = real_time_fps_test(
    #     model_path=r'AFPM-Net.pt',
    #     camera_index=0,
    #     duration=10
    # )