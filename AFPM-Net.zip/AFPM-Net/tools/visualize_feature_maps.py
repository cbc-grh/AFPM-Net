import os
import cv2
import numpy as np
from pathlib import Path

import torch
from ultralytics import YOLO


# =========================================================
# 用户配置区域：只需要修改这里
# =========================================================
WEIGHTS_PATH = r"weights/AFPM-Net.pt"   # 你的权重路径
SOURCE_PATH = r"docs/1.jpg"                          # 单张图片路径或图片文件夹路径
SAVE_DIR = r"feature_map_results_ours"                     # 结果保存目录

IMG_SIZE = 640                                        # 输入尺寸
DEVICE = "cuda:0" if torch.cuda.is_available() else "cpu"

# 提取的层编号
TARGET_LAYERS = [0, 1, 12]

# 激活图计算方式，可选：
# "abs_mean" / "relu_mean" / "mean" / "max" / "l2"
ACTIVATION_MODE = "abs_mean"

# heatmap叠加透明度
ALPHA = 0.45

# 是否保存原始激活图npy文件
SAVE_NPY = False
# =========================================================


IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"}


def make_dir(path):
    os.makedirs(path, exist_ok=True)


def list_images(source):
    source = Path(source)
    if source.is_file():
        return [source]
    elif source.is_dir():
        imgs = []
        for p in source.rglob("*"):
            if p.suffix.lower() in IMG_EXTS:
                imgs.append(p)
        return sorted(imgs)
    else:
        raise FileNotFoundError(f"Source path does not exist: {source}")


def letterbox(
    img,
    new_shape=640,
    color=(114, 114, 114),
    auto=False,
    scale_fill=False,
    scaleup=True,
    stride=32,
):
    """
    与YOLO预处理一致的letterbox。
    """
    shape = img.shape[:2]  # (h, w)

    if isinstance(new_shape, int):
        new_shape = (new_shape, new_shape)

    r = min(new_shape[0] / shape[0], new_shape[1] / shape[1])
    if not scaleup:
        r = min(r, 1.0)

    ratio = (r, r)
    new_unpad = (int(round(shape[1] * r)), int(round(shape[0] * r)))  # (w, h)
    dw = new_shape[1] - new_unpad[0]
    dh = new_shape[0] - new_unpad[1]

    if auto:
        dw = np.mod(dw, stride)
        dh = np.mod(dh, stride)
    elif scale_fill:
        dw, dh = 0.0, 0.0
        new_unpad = (new_shape[1], new_shape[0])
        ratio = (new_shape[1] / shape[1], new_shape[0] / shape[0])

    dw /= 2
    dh /= 2

    if shape[::-1] != new_unpad:
        img = cv2.resize(img, new_unpad, interpolation=cv2.INTER_LINEAR)

    top = int(round(dh - 0.1))
    bottom = int(round(dh + 0.1))
    left = int(round(dw - 0.1))
    right = int(round(dw + 0.1))

    img = cv2.copyMakeBorder(
        img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=color
    )

    return img, ratio, (dw, dh)


def preprocess_image(img_path, imgsz=640, device="cpu"):
    """
    读取图像并做letterbox，输出：
    - 原始BGR图
    - letterbox后的BGR图
    - 输入tensor [1,3,H,W]
    """
    img_bgr = cv2.imread(str(img_path))
    if img_bgr is None:
        raise ValueError(f"Cannot read image: {img_path}")

    img_lb, ratio, pad = letterbox(img_bgr, new_shape=imgsz)

    img_rgb = cv2.cvtColor(img_lb, cv2.COLOR_BGR2RGB)
    img_rgb = img_rgb.astype(np.float32) / 255.0

    x = torch.from_numpy(img_rgb).permute(2, 0, 1).unsqueeze(0).to(device)

    return img_bgr, img_lb, x, ratio, pad


def normalize_map(act, eps=1e-8):
    act_min = np.min(act)
    act_max = np.max(act)
    act = (act - act_min) / (act_max - act_min + eps)
    return act


def feature_to_activation_map(feat, mode="abs_mean"):
    """
    将多通道特征图 [1,C,H,W] 或 [C,H,W] 压缩成单通道激活图 [H,W]
    """
    if isinstance(feat, (tuple, list)):
        tensors = [x for x in feat if torch.is_tensor(x)]
        if len(tensors) == 0:
            raise TypeError("Feature output contains no tensor.")
        feat = tensors[0]

    if not torch.is_tensor(feat):
        raise TypeError(f"Feature is not tensor, got {type(feat)}")

    feat = feat.detach().float().cpu()

    if feat.ndim == 4:
        feat = feat[0]  # [C,H,W]
    elif feat.ndim == 3:
        pass
    else:
        raise ValueError(f"Unsupported feature shape: {feat.shape}")

    if mode == "abs_mean":
        act = feat.abs().mean(dim=0)
    elif mode == "relu_mean":
        act = torch.relu(feat).mean(dim=0)
    elif mode == "mean":
        act = feat.mean(dim=0)
    elif mode == "max":
        act = feat.max(dim=0).values
    elif mode == "l2":
        act = torch.sqrt(torch.sum(feat ** 2, dim=0) + 1e-8)
    else:
        raise ValueError(f"Unsupported activation mode: {mode}")

    return act.numpy()


def save_activation_results(act, img_lb, save_prefix, alpha=0.45):
    """
    保存灰度图、热力图、叠加图
    """
    h, w = img_lb.shape[:2]
    act = normalize_map(act)
    act_resized = cv2.resize(act, (w, h), interpolation=cv2.INTER_LINEAR)

    gray = np.uint8(act_resized * 255)
    heatmap = cv2.applyColorMap(gray, cv2.COLORMAP_JET)
    overlay = cv2.addWeighted(img_lb, 1 - alpha, heatmap, alpha, 0)

    cv2.imwrite(str(save_prefix) + "_gray.png", gray)
    cv2.imwrite(str(save_prefix) + "_heatmap.png", heatmap)
    cv2.imwrite(str(save_prefix) + "_overlay.png", overlay)


def get_module_name(module):
    return module.__class__.__name__


class FeatureHookExtractor:
    def __init__(self, model, layer_ids):
        """
        model: ultralytics YOLO(...).model
        layer_ids: 要提取的层编号列表
        """
        self.model = model
        self.layers = model.model
        self.layer_ids = layer_ids
        self.features = {}
        self.handles = []

        self.register_hooks()

    def register_hooks(self):
        for idx in self.layer_ids:
            if idx < 0 or idx >= len(self.layers):
                raise IndexError(
                    f"Layer index {idx} is out of range. Total layers: {len(self.layers)}"
                )

            layer = self.layers[idx]

            def make_hook(layer_idx):
                def hook(module, inp, out):
                    self.features[layer_idx] = out
                return hook

            handle = layer.register_forward_hook(make_hook(idx))
            self.handles.append(handle)

    def clear(self):
        self.features = {}

    def remove(self):
        for h in self.handles:
            h.remove()
        self.handles = []

    @torch.no_grad()
    def forward(self, x):
        self.clear()
        _ = self.model(x)
        return self.features


def print_model_layers(yolo_model):
    print("\n================ Model Layers ================")
    for i, m in enumerate(yolo_model.model.model):
        print(f"{i:03d}: {get_module_name(m)}")
    print("=============================================\n")


def main():
    print("Loading model...")
    yolo = YOLO(WEIGHTS_PATH)
    yolo.model.to(DEVICE)
    yolo.model.eval()

    print(f"Model loaded from: {WEIGHTS_PATH}")
    print(f"Using device: {DEVICE}")

    # 打印模型层，方便确认0/1/14层
    print_model_layers(yolo)

    # 检查目标层名称
    print("Target layers:")
    for idx in TARGET_LAYERS:
        print(f"  Layer {idx}: {get_module_name(yolo.model.model[idx])}")

    make_dir(SAVE_DIR)

    # 保存层列表
    with open(os.path.join(SAVE_DIR, "model_layers.txt"), "w", encoding="utf-8") as f:
        for i, m in enumerate(yolo.model.model):
            f.write(f"{i:03d}: {get_module_name(m)}\n")

    extractor = FeatureHookExtractor(yolo.model, TARGET_LAYERS)

    image_paths = list_images(SOURCE_PATH)
    print(f"Found {len(image_paths)} image(s).")

    for img_path in image_paths:
        print(f"Processing: {img_path}")

        img_bgr, img_lb, x, ratio, pad = preprocess_image(
            img_path, imgsz=IMG_SIZE, device=DEVICE
        )

        img_name = Path(img_path).stem
        img_save_dir = os.path.join(SAVE_DIR, img_name)
        make_dir(img_save_dir)

        # 保存输入图
        cv2.imwrite(os.path.join(img_save_dir, "input_letterbox.png"), img_lb)

        # 前向提取特征
        features = extractor.forward(x)

        for layer_idx in TARGET_LAYERS:
            if layer_idx not in features:
                print(f"Warning: feature of layer {layer_idx} not captured.")
                continue

            feat = features[layer_idx]
            layer_name = get_module_name(yolo.model.model[layer_idx])

            act = feature_to_activation_map(feat, mode=ACTIVATION_MODE)

            prefix = os.path.join(
                img_save_dir,
                f"layer_{layer_idx:03d}_{layer_name}_{ACTIVATION_MODE}"
            )

            save_activation_results(act, img_lb, prefix, alpha=ALPHA)

            if SAVE_NPY:
                np.save(prefix + "_activation.npy", act)

            # 保存信息
            if torch.is_tensor(feat):
                feat_shape = tuple(feat.shape)
            elif isinstance(feat, (tuple, list)):
                feat_shape = [tuple(x.shape) for x in feat if torch.is_tensor(x)]
            else:
                feat_shape = str(type(feat))

            with open(prefix + "_info.txt", "w", encoding="utf-8") as f:
                f.write(f"image_path: {img_path}\n")
                f.write(f"layer_index: {layer_idx}\n")
                f.write(f"layer_name: {layer_name}\n")
                f.write(f"feature_shape: {feat_shape}\n")
                f.write(f"activation_mode: {ACTIVATION_MODE}\n")
                f.write(f"input_shape(letterbox): {img_lb.shape}\n")
                f.write(f"ratio: {ratio}\n")
                f.write(f"pad: {pad}\n")

        print(f"Saved to: {img_save_dir}")

    extractor.remove()
    print("Done.")


if __name__ == "__main__":
    main()