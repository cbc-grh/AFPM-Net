import matplotlib

matplotlib.use('Agg')  # 使用无窗口后端
from ultralytics import YOLO
import torch
from thop import profile  # 导入thop库


def main():
    # 加载模型
    model_path = r'weights/AFPM-Net.pt'
    model = YOLO(model_path)

    # 计算GFLOPs和参数量
    input_tensor = torch.randn(1, 3, 640, 640).to(model.device)  # 创建随机输入张量
    flops, params = profile(model.model, inputs=(input_tensor,), verbose=False)
    gflops = flops / 1e9  # 转换为GFLOPs

    print(f"模型参数: {params / 1e6:.2f} M")
    print(f"计算量: {gflops:.2f} GFLOPs")

    # 模型验证
    model.val(
        data=r'datasets/VisDrone.yaml',
        batch=8,
        device=0
    )


if __name__ == '__main__':
    main()