import torch
import torch.nn as nn
import torch.fft
import torch.nn.functional as F
import cv2
from ultralytics.nn.modules import Conv


class SPDStep(nn.Module):
    """单步SPD下采样（改进版）"""
    def __init__(self, c1, c2):
        super().__init__()
        self.c1 = c1
        # 空间到深度变换后通道数为4*c1，通过1x1卷积调整到目标通道数
        self.conv = nn.Conv2d(c1 * 4, c2, 1, 1, 0, bias=False)  # 无偏置，后续BN处理

    def forward(self, x):
        b, c, h, w = x.shape

        # 动态填充：确保下采样前尺寸为偶数，避免尺寸不匹配
        if h % 2 != 0 or w % 2 != 0:
            pad_h = 1 if h % 2 != 0 else 0
            pad_w = 1 if w % 2 != 0 else 0
            x = F.pad(x, (0, pad_w, 0, pad_h), mode='constant', value=0)  # 边缘填充0
            h, w = x.shape[2], x.shape[3]  # 更新尺寸

        # 空间到深度变换（无冗余设备操作）
        x0 = x[..., ::2, ::2]  # 左上角
        x1 = x[..., 1::2, ::2]  # 左下角
        x2 = x[..., ::2, 1::2]  # 右上角
        x3 = x[..., 1::2, 1::2]  # 右下角

        # 拼接通道维度（4*c1）
        x = torch.cat([x0, x1, x2, x3], dim=1)

        # 调整通道数并返回
        return self.conv(x)


class ProgressiveSPDConv(nn.Module):
    """渐进式下采样SPDConv（改进版），适配YOLOv11第一层"""
    def __init__(self, c1, c2, k=1, s=1, g=1, d=1, act=True, steps=1):
        super().__init__()
        self.c1 = c1
        self.c2 = c2
        self.steps = steps
        self.total_stride = 2 **steps  # 总下采样倍数：2^steps

        # 渐进式下采样模块
        self.progressive_layers = nn.ModuleList()
        current_channels = c1
        # Conv = nn.Sequential(
        #     nn.Conv2d(c1, c2, kernel_size=3, stride=1, padding=1),
        #     nn.BatchNorm2d(c2),
        #     nn.SiLU(inplace=True)
        # )


        for i in range(steps):
            if i == steps - 1:
                # 最后一步输出目标通道数
                out_channels = c2
            else:
                # 优化通道数计算，确保整数（避免小数取整误差）
                out_channels = (c1 * (steps - i - 1) + c2 * (i + 1) + steps - 1) // steps

            # 每步：SPD下采样 + 3x3卷积（保持尺寸）
            layer = nn.Sequential(
                SPDStep(current_channels, out_channels),
                Conv(out_channels, out_channels, 3, 1, 1, g=g, act=act)  # 3x3同卷积
            )
            self.progressive_layers.append(layer)
            current_channels = out_channels

        # 改进残差连接：添加与主分支匹配的下采样
        if c1 != c2 or self.total_stride > 1:
            # 先下采样（最大池化）再调整通道
            self.shortcut = nn.Sequential(
                nn.MaxPool2d(kernel_size=self.total_stride, stride=self.total_stride),
                Conv(c1, c2, 1, 1, 0, act=False)  # 1x1卷积调整通道
            )
        else:
            # 通道和尺寸均不变时直接恒等映射
            self.shortcut = nn.Identity()

    def forward(self, x):
        # 残差分支（含下采样，与主分支尺寸匹配）
        residual = self.shortcut(x)

        # 主分支：渐进式下采样
        for layer in self.progressive_layers:
            x = layer(x)

        # 残差相加（尺寸和通道数已匹配）
        return x + residual


class AdaptiveFreqStem(nn.Module):  # 对应论文AFS
    def __init__(self, in_channels, out_channels, p=None, st=2, *args):
        super().__init__()
        print(f"Initializing stem: in={in_channels}, out={out_channels}, st={st}")
        base_channels = out_channels // 2

        self.edge_path = nn.Sequential(
            nn.Conv2d(in_channels, 8, 3, padding=1, bias=False),
            nn.BatchNorm2d(8),
            nn.ReLU(inplace=True),
            AdaptiveSobelBlock(8, base_channels)
        )

        self.freq_path = nn.Sequential(
            nn.Conv2d(in_channels, 8, 1),
            FreqAwareProj(8, base_channels)
        )

        self.fusion = DualAttentionFusion(2 * base_channels)

        # self.output_conv = nn.Sequential(
        #     nn.Conv2d(2 * base_channels, out_channels, 3, stride=st, padding=1),
        #     nn.BatchNorm2d(out_channels),
        #     nn.SiLU(inplace=True)
        # )
        self.output_conv = ProgressiveSPDConv(2 * base_channels, out_channels, 3)

    def forward(self, x):
        edge_feat = self.edge_path(x)
        freq_feat = self.freq_path(x)
        fused = torch.cat([edge_feat, freq_feat], dim=1)
        return self.output_conv(self.fusion(fused))


class AdaptiveSobelBlock(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()
        self.sobel_base = nn.Parameter(torch.randn(8, in_c, 3, 3) * 0.1)

        self.dir_conv = nn.Sequential(
            nn.Conv2d(8, out_c, 1),
            nn.BatchNorm2d(out_c),
            nn.ReLU(inplace=True)
        )

        with torch.no_grad():
            sobel_x = torch.tensor([[[[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]]]], dtype=torch.float32)
            sobel_y = torch.tensor([[[[-1, -2, -1], [0, 0, 0], [1, 2, 1]]]], dtype=torch.float32)

            sobel_x_full = sobel_x.repeat(1, in_c, 1, 1)
            sobel_y_full = sobel_y.repeat(1, in_c, 1, 1)

            self.sobel_base[0] = sobel_x_full.squeeze(0)
            self.sobel_base[1] = sobel_y_full.squeeze(0)

    def forward(self, x):
        feats = []
        for i in range(8):
            kernel = self.sobel_base[i].unsqueeze(0)  # [1, in_c, 3, 3]
            feats.append(F.conv2d(x, kernel, padding=1))
        multi_dir = torch.cat(feats, dim=1)  # [B, 8, H, W]
        return self.dir_conv(multi_dir)


class FreqAwareProj(nn.Module):
    def __init__(self, in_c, out_c):
        super().__init__()
        self.spatial_conv = nn.Sequential(
            nn.Conv2d(in_c, out_c // 2, 3, padding=1),
            nn.ReLU(inplace=True)
        )
        self.freq_conv = nn.Sequential(
            nn.Conv2d(in_c, out_c // 2, 1),
            FreqMaskApprox(out_c // 2)
        )

    def forward(self, x):
        spatial = self.spatial_conv(x)
        freq = self.freq_conv(x)
        return torch.cat([spatial, freq], dim=1)


class FreqMaskApprox(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.channels = channels
        self.gen_weights = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, 4 * channels, 1),
            nn.ReLU(),
            nn.Conv2d(4 * channels, 9 * channels, 1)  # 为每个通道生成9个权重
        )
        self.radius = nn.Parameter(torch.tensor(0.2))

    def forward(self, x):
        B, C, H, W = x.shape
        original_dtype = x.dtype  # 保存原始数据类型

        # 获取动态权重 [B, 9*C, 1, 1]
        weights = self.gen_weights(x)

        # 重塑为 [B, C, 3, 3]
        weights = weights.view(B, C, 3, 3)

        # 创建基础拉普拉斯核 [3,3]
        base_kernel = torch.tensor([[0, -1, 0],
                                    [-1, 4, -1],
                                    [0, -1, 0]],
                                   dtype=original_dtype, device=x.device)  # 使用原始数据类型

        # 扩展基础核 [B, C, 3, 3]
        base_kernel = base_kernel.unsqueeze(0).unsqueeze(0)  # [1, 1, 3, 3]
        base_kernel = base_kernel.expand(B, C, 3, 3)

        # 最终卷积核 [B, C, 3, 3]
        kernel = base_kernel * self.radius + weights * (1 - self.radius)

        # 确保卷积核的数据类型与输入一致
        kernel = kernel.to(original_dtype)

        # 重塑为深度卷积核 [B*C, 1, 3, 3]
        kernel = kernel.view(B * C, 1, 3, 3)

        # 输入重塑 [1, B*C, H, W]
        x_grouped = x.view(1, B * C, H, W)

        # 使用分组卷积（相当于深度卷积）
        output = F.conv2d(x_grouped, kernel, padding=1, groups=B * C)

        # 恢复原始形状 [B, C, H, W]
        output = output.view(B, C, H, W)

        return output


class DualAttentionFusion(nn.Module):
    def __init__(self, channels):
        super().__init__()
        # 确保通道数至少为4
        reduced_channels = max(4, channels // 4)

        self.spatial_att = nn.Sequential(
            nn.Conv2d(channels, reduced_channels, 1),
            nn.ReLU(),
            nn.Conv2d(reduced_channels, 1, 3, padding=1),
            nn.Sigmoid()
        )
        self.channel_att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, reduced_channels, 1),
            nn.ReLU(),
            nn.Conv2d(reduced_channels, channels, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        spatial_w = self.spatial_att(x)
        channel_w = self.channel_att(x)
        return x * spatial_w * channel_w
