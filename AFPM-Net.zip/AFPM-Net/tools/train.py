from ultralytics import YOLO


if __name__ == '__main__':
    # 加载一个预训练的 YOLO11n 模型
    model = YOLO(r"AFPM-Net.yaml")

    # 在 VisDrone2019 数据集上训练模型 200 个周期
    train_results = model.train(
        data=r"datasets/VisDrone.yaml",  # 数据集配置文件路径
        epochs=200,  # 训练周期数
        imgsz=640,  # 训练图像尺寸
        batch=8,
        device=0,  # 运行设备（例如 'cpu', 0, [0,1,2,3]）
    )